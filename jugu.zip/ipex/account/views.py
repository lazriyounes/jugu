from django.shortcuts import render,redirect
from django.http import HttpResponse



# Create your views here.

def sign(request):
     
     if request.method =="POST":
            username =request.POST.get("username")
            password =request.POST.get("password")


            if username=="admin" and password =="123":

             return redirect('index')
            else:
                return HttpResponse("votre nom d'utilisateur ou mot de pass est fausse")
         


     return render(request,'signup1.html')