from django.shortcuts import render,redirect ,get_object_or_404
from django.db.models import Count
from .models import *
from .forms import ProductForm ,CatForm ,WilayaForm

# Create your views here.
def pres(request):
       if request.method =='POST':
        pro =ProductForm(request.POST,request.FILES)
        if pro.is_valid():
             pro.save()
             return redirect('/az/pres')

        cats =CatForm(request.POST )
        if cats.is_valid():
             cats.save()
             return redirect('/az/pres')
        
        wil =WilayaForm(request.POST,request.FILES)
        if wil.is_valid():
             wil.save()
             return redirect('/az/pres')
        
        
       context ={
        'prod':Produit.objects.all(),
         'wila':Wilaya.objects.all(),
        'cat' : Categoryprod.objects.all(),
       'form' : ProductForm(),
       'wilaya':WilayaForm(),
       'categ':CatForm(),
       'allproduit':Produit.objects.filter(active=True).count(),
     
       
                'wc': Produit.objects.filter().count()/15,

        'pcul':Produit.objects.filter(categoryproduit='cultivés').count(),
       'pagro':Produit.objects.filter(categoryproduit='industrie agro-alimentaires').count(),
        'pcom':Produit.objects.filter(categoryproduit='commercialisés').count(),
    }
       return render(request,'pag/pres.html',context)
def index(request):
    wy = Wilaya.objects.get(id=1)
    wc=wy.prodlocal
    for op in wc :
         wc = op.split(',')
         
        
    if request.method =='POST':
        produ =ProductForm(request.POST,request.FILES)
        if produ.is_valid():
             produ.save()
             return redirect('/az/0')

        catsave =CatForm(request.POST )
        if catsave.is_valid():
             catsave.save()
             return redirect('/az/0')
        
        wi =WilayaForm(request.POST,request.FILES)
        if wi.is_valid():
             wi.save()
             return redirect('/az/0')
     
        
        
    context ={
        'prod':Produit.objects.all(),
         'wila':Wilaya.objects.all(),
        'cat' : Categoryprod.objects.all(),
       'form' : ProductForm(),
       'wilaya':WilayaForm(),
       'categ':CatForm(),
       'allproduit':Produit.objects.filter(active=True).count(),
       'allwilaya':Wilaya.objects.count(),
       'wc': Produit.objects.filter().count()/15,
     
        'pcul':Produit.objects.filter(categoryproduit='cultivés').count(),
       'pagro':Produit.objects.filter(categoryproduit='industrie agro-alimentaires').count(),
        'pcom':Produit.objects.filter(categoryproduit='commercialisés').count(),
       
    }
    return render(request,'pag/index.html',context)


























def second(request):
             search =Produit.objects.all()
             title=None
             if 'search_name' in request.GET:
                title=request.GET['search_name']

             if title:
              search=search.filter(nameprod__icontains = title)



             context ={
                  'prod':search,
                  'cat' : Categoryprod.objects.all(),
            }
   

             return render(request,'pag/prod.html',context)
    

def update(request,id):
   
   pid = Wilaya.objects.get(id=id)
   if request.method =='POST':
        psave =WilayaForm(request.POST,request.FILES,instance=pid)
        if psave.is_valid():
             psave.save()
             return redirect('/az/0')
        
     
   else:
        psave = WilayaForm(instance=pid)         
        context ={
             'form':psave ,
          

        }

   

  
   return render(request,'pag/update.html',context)




def modifier(request,id):
   
   pidd = Produit.objects.get(id=id)
   if request.method =='POST':
        psaves =ProductForm(request.POST,request.FILES,instance=pidd)
        if psaves.is_valid():
             psaves.save()
             return redirect('/az/0')
        
     
   else:
        psaves = ProductForm(instance=pidd)         
        context ={
             'forms':psaves
        }

   

  
   return render(request,'pag/update2.html',context)

def delete(request,id):
       proid = get_object_or_404(Wilaya,id=id)
      
       if request.method =='POST':
         proid.delete() 
         return redirect('/az/0')
     
       return render(request,'pag/delete.html')




def delete2(request,id):
       
       



       
       p = get_object_or_404(Produit,id=id)
      
       if request.method =='POST':
         p.delete() 
         return redirect('/az/0')
     
       return render(request,'pag/delete2.html')





def pres2(request):
             search =Produit.objects.all()
             title=None
             if 'search_name' in request.GET:
                title=request.GET['search_name']

             if title:
              search=search.filter(nameprod__icontains = title)



             context ={
                  'prod':search,
                  'cat' : Categoryprod.objects.all(),
            }
   

             return render(request,'pag/produit.html',context)
    