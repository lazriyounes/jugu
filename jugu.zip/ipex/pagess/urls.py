from django.urls import path
from . import views
urlpatterns =[   
    path('/0' ,views.index , name='index'),
     path('/wilaya' ,views.second , name='second'),
      path('/update<int:id>' ,views.update , name='update'),
       path('/delete2<int:id>' ,views.delete2 , name='delete2'),
       path('/delete<int:id>' ,views.delete , name='delete'),
       path('/modifier<int:id>' ,views.modifier , name='modifier'),
         path('/pres' ,views.pres , name='pres'),
          path('/pres2' ,views.pres2 , name='pres2'),
       
     
]
