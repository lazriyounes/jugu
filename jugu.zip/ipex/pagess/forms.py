from django import forms
from .models import Produit ,Categoryprod ,Book,Author,Wilaya
class CatForm(forms.ModelForm):
    class Meta :
        model =Categoryprod
        fields =[
            'name' ,
        ]
        widgets={
             'name': forms.TextInput(attrs={'class':'form-control'}),
         }
class ProductForm(forms.ModelForm):
    class Meta :
        model = Produit
        fields =[
             'nameprod' ,
            'categoryproduit',
             'catprod',
            
        ]
        widgets={
             'nameprod' : forms.TextInput(attrs={'class':'form-control'}),
              'categoryproduit': forms.Select(attrs={'class':'form-control'}),
             'catprod': forms.Select(attrs={'class':'form-control'}),
              
        }



class WilayaForm(forms.ModelForm):
    class Meta :
        model =Wilaya
        fields =[
                'nomwilaya',
                'prodlocal' ,
                'prodimporter', 
        ]
        widgets={
             'nomwilaya': forms.TextInput(attrs={'class':'form-control'}),
              'prodlocal' :forms.CheckboxSelectMultiple(attrs={'class':'form-inline'}),
               'prodimporter': forms.CheckboxSelectMultiple(attrs={'class':'form-inline'}),
         }